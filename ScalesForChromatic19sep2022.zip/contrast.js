// contrast.js

function changeContrast(changeScreen) {
  if (changeScreen == true) {
    document.documentElement.style.setProperty("--bg-color", "#000000");
    document.body.style.backgroundColor = "#000000";
    document.documentElement.style.setProperty("--txt-color", "#ffffff");
  } else {
    document.documentElement.style.setProperty("--bg-color", "#282828");
    document.documentElement.style.setProperty("--txt-color", "#a8a8a8");
  }
}

function contraster() {
  var confirmMessage = versionTitle + " "
    + versionDate + " "
    + versionNum + " "
    + "\nChoose to set contrast of the interface to either:\n"
    + "\n  OK - Optimized contrast (Default-Recommended)"
    + "\n  Cancel - Black / white";

  var contrast = confirm(confirmMessage);
  if (contrast) {
    changeContrast(false);
  } else {
    changeContrast(true);
  };
}

// contrast.js